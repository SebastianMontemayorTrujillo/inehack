CCPC 2024 research reproduction annex
Verified 23 October 2026. This is a research utility, not a game implementation.

PURPOSE
Reproduce national, Aguascalientes, Baja California and three age-band aggregates
used to design neutral data-literacy quests for an INE Reto 3 proposal. It does not
estimate motives, individual voting behaviour, future turnout or learning impact.

SOURCE
Official INE portal:
https://ine.mx/transparencia/datos-abiertos/visualizacion-datos/conteos-censales-participacion/
Official source ZIP (not included, 82,419,841 bytes):
https://ine.mx/wp-content/uploads/2025/08/DatosAbiertos_DECEyEC_ConteosCensales2024.zip
Inspected SHA-256:
c0de34d04e782ad99579b83591a6e3e6c8d1e20f4914d4845743bd79d2bd28b2
Official manual, indicator definitions on pages 17-18:
https://ine.mx/wp-content/uploads/2025/06/Manual-Conteos-Censales-2009-2024.pdf
Dictionary inside the official ZIP:
DatosAbiertos_DECEyEC_ConteosCensales2024/01_descripcioncampos_conteoscensales2024.txt

RUN
Requires Python 3.9 or later, standard library only. No installation or network
access occurs. Download the source ZIP separately and preserve it unchanged.

python reproduce_ccpc2024.py /path/to/CCPC2024.zip --output results.json

Omit --output to print JSON to standard output. Runtime depends on the computer;
the source has 32 CSV files and 9,773,730 rows. Inspect warnings and exit status.
The script does not unzip files to disk. An explicit output JSON overwrites that
output path, so choose a new filename if you need to retain earlier results.

INSPECTED CSV HEADER, IN ORDER
AELEC, FELECCION, EDOCVE, EDONOM, MPIOCVE, MPIONOM, SECCION, TIPOSEC,
DEF, DEL, SEXO, EDAD, LN, SV, NV, NS

FIELDS USED
AELEC: election year, expected 2024.
EDOCVE: INE state code; 1 = Aguascalientes, 2 = Baja California.
EDAD: age on election day; inclusive bands 18-19, 20-24, 25-29.
LN: nominal-list records from catalogued polling-station booklets.
SV: records marked as voted.
NV: records without the voted mark.
NS: participation unspecified because booklet/page evidence is unavailable or
otherwise unspecified, per the dictionary. NS is not a null ballot or abstention.
SEXO and other dimensions are not filtered: the selected aggregates include all.
TIPOSEC codes are U (urban), M (mixed), R (rural). SEXO codes in 2024 are
0 (men), 1 (women), 2 (nonbinary). These values are not individual identities.
Indigenous/Afrodescendant filters in the dashboard are not fields in this CSV.
FELECCION is not parsed: AELEC establishes the election year, avoiding locale guesses.

DENOMINATORS AND ROUNDING
Participation percentage = 100 * sum(SV) / (sum(SV) + sum(NV)).
Unknown percentage = 100 * sum(NS) / sum(LN).
Sum counts first, not percentages. Zero denominators produce null, not zero.
Raw JSON retains full floating-point results. Use one or two decimals in player
text and preserve the exact counts in the evidence ledger. A 100-person icon
array is a rounded illustration, not an actual sample of 100 people.
The incorrect unweighted two-state mean is included deliberately as a teaching
contrast, not as an alternative valid estimate of combined participation.

SCOPE AND CHECKS
Checks: exact schema, election year, integer/nonnegative counts, state coverage,
32 CSV files, row-wise LN=SV+NV+NS, source hash. A nonmatching source hash warns;
it may indicate a legitimate revision, which must be investigated before reuse.
No uniqueness or complete source-quality audit is claimed. Do not count this
research utility as implementation or playtesting of the proposed game.
Source excludes special polling stations and voting from abroad. CCPC uses
nominal-list-booklet marks and can differ from district election results.
Do not infer party preference, personal motivation or intervention effects.
Do not naively join historical district codes: cartographic references differ.

CROSS-CHECK
INE June 2025 census integration report, pages 16-17, reports national SV of
54,899,228 and turnout 59.7%; age rates 56.8%, 48.4%, 47.3% respectively. These
match the rounded results here. This is not the separate December 2024 sample.
https://repositoriodocumental.ine.mx/xmlui/bitstream/handle/123456789/183892/cceyec-2so-25-06-25-p4-vf.pdf

CONTENTS
reproduce_ccpc2024.py: portable research-only utility.
verified_ccpc2024.json: full rerun against the inspected official ZIP.
README.txt: source, methodology, definitions and limitations.

VALIDATION PERFORMED ON 23 OCTOBER 2026
Full portable rerun reproduced every reported count and rate from the independent
first calculation. Source hash matched; 32 CSVs; 9,773,730 rows; zero arithmetic
violations. Synthetic checks also passed for aggregation and zero-denominator
handling. No gameplay or educational-impact validation was performed.
