#!/usr/bin/env python3
"""Research utility: reproduce selected aggregates from the official CCPC 2024 ZIP.
No downloads, network calls, game code, third-party packages, or personal identifiers.
"""
import argparse
import csv
import hashlib
import io
import json
import sys
import zipfile
from collections import defaultdict
from pathlib import Path

SOURCE_URL = 'https://ine.mx/wp-content/uploads/2025/08/DatosAbiertos_DECEyEC_ConteosCensales2024.zip'
VERIFIED_SHA256 = 'c0de34d04e782ad99579b83591a6e3e6c8d1e20f4914d4845743bd79d2bd28b2'
FIELDS = ['AELEC', 'FELECCION', 'EDOCVE', 'EDONOM', 'MPIOCVE', 'MPIONOM',
          'SECCION', 'TIPOSEC', 'DEF', 'DEL', 'SEXO', 'EDAD', 'LN', 'SV', 'NV', 'NS']
COUNTS = ('LN', 'SV', 'NV', 'NS')
SELECTED = ('national', 'state_1', 'state_2', 'age_18_19', 'age_20_24', 'age_25_29')


def empty_group():
    return dict(LN=0, SV=0, NV=0, NS=0, rows=0)


def aggregate(zip_path):
    """Return reproducible descriptive aggregates; reject malformed input."""
    sha = hashlib.sha256()
    with zip_path.open('rb') as raw:
        for block in iter(lambda: raw.read(1024 * 1024), b''):
            sha.update(block)
    digest = sha.hexdigest()
    groups = defaultdict(empty_group)
    bad_sum_rows = 0
    states = set()
    with zipfile.ZipFile(zip_path) as archive:
        members = sorted(name for name in archive.namelist() if name.lower().endswith('.csv'))
        if len(members) != 32:
            raise ValueError(f'Expected 32 state CSV files; found {len(members)}. Do not call a partial ZIP national.')
        for member in members:
            with archive.open(member) as binary:
                reader = csv.DictReader(io.TextIOWrapper(binary, encoding='utf-8-sig', newline=''))
                if reader.fieldnames != FIELDS:
                    raise ValueError(f'Unexpected schema in {member}: {reader.fieldnames!r}')
                for line, row in enumerate(reader, start=2):
                    if row['AELEC'] != '2024':
                        raise ValueError(f'Unexpected election year in {member}, line {line}')
                    try:
                        values = {field: int(row[field]) for field in COUNTS}
                        age = int(row['EDAD'])
                        state = int(row['EDOCVE'])
                    except (TypeError, ValueError) as exc:
                        raise ValueError(f'Invalid count, age or state in {member}, line {line}') from exc
                    if state not in range(1, 33) or min(values.values()) < 0:
                        raise ValueError(f'Invalid state or negative count in {member}, line {line}')
                    states.add(state)
                    bad_sum_rows += values['LN'] != values['SV'] + values['NV'] + values['NS']
                    keys = ['national']
                    if state in (1, 2):
                        keys.append(f'state_{state}')
                    if 18 <= age <= 19:
                        keys.append('age_18_19')
                    elif 20 <= age <= 24:
                        keys.append('age_20_24')
                    elif 25 <= age <= 29:
                        keys.append('age_25_29')
                    for key in keys:
                        for field in COUNTS:
                            groups[key][field] += values[field]
                        groups[key]['rows'] += 1
    if states != set(range(1, 33)):
        raise ValueError(f'Missing state coverage: {sorted(set(range(1, 33)) - states)}')
    for group in groups.values():
        denominator = group['SV'] + group['NV']
        group['classified_denominator'] = denominator
        group['turnout_pct'] = 100 * group['SV'] / denominator if denominator else None
        group['unknown_pct'] = 100 * group['NS'] / group['LN'] if group['LN'] else None
    one, two = groups['state_1'], groups['state_2']
    combined_denominator = one['classified_denominator'] + two['classified_denominator']
    result = {
        'purpose': 'Research reproduction utility, not game implementation or an impact evaluation.',
        'source_url': SOURCE_URL,
        'sha256': digest,
        'matches_source_inspected_2026_10_23': digest == VERIFIED_SHA256,
        'csv_files': len(members),
        'schema_fields': FIELDS,
        'bad_sum_rows': bad_sum_rows,
        'groups': {key: groups[key] for key in SELECTED},
        'two_state_combined_pct': 100 * (one['SV'] + two['SV']) / combined_denominator if combined_denominator else None,
        'two_state_unweighted_pct': (one['turnout_pct'] + two['turnout_pct']) / 2 if one['turnout_pct'] is not None and two['turnout_pct'] is not None else None,
        'limits': [
            'Arithmetic checks do not establish uniqueness, completeness or source accuracy.',
            'SV/(SV+NV) is a classified nominal-list-record rate; NS is unknown, not abstention.',
            'Special polling stations and voting from abroad are excluded by the source dictionary.',
            'Descriptive aggregates do not establish causes, motives, individual behaviour or intervention effects.',
        ],
    }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input_zip', type=Path, help='Locally downloaded official CCPC 2024 ZIP')
    parser.add_argument('-o', '--output', type=Path, help='Optional output JSON path; otherwise print to stdout')
    args = parser.parse_args()
    if args.output and args.output.resolve() == args.input_zip.resolve():
        parser.error('Output must not overwrite the input ZIP.')
    try:
        result = aggregate(args.input_zip)
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as exc:
        print(f'Cannot reproduce aggregates: {exc}', file=sys.stderr)
        return 1
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if args.output:
        args.output.write_text(rendered, encoding='utf-8')
        print(f'Wrote {args.output}', file=sys.stderr)
    else:
        print(rendered, end='')
    if result['bad_sum_rows']:
        print('ERROR: LN differs from SV+NV+NS in at least one row; do not reuse without investigation.', file=sys.stderr)
        return 2
    if not result['matches_source_inspected_2026_10_23']:
        print('WARNING: input differs from the source inspected on 2026-10-23; investigate before reuse.', file=sys.stderr)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
