INEhack planning research annex

Contents
- Codex_Prompts_and_Feature_Spec.txt: planning templates, not executed game implementation.
- ccpc/: exact verified 2024 aggregate outputs, portable no-network reproduction utility, and its source/instructions README.

The official raw ZIP is not included. The utility requires a separately obtained official ZIP, checks its source hash, and reproduces the documented aggregates. It does not build a game or collect personal information.

Use alongside INEhack Development Blueprint and INEhack Learning Evidence and Pitch Outline. No prototype learning or turnout effects are claimed.
